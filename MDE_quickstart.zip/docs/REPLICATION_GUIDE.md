Follow the steps to fetch real data and run models.
